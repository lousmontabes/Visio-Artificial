﻿# vision-artificial-UB
Prácticas de Visión Artificial - Universitat de Barcelona

Curso 2018-2019
